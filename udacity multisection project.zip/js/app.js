let theSections = document.querySelectorAll('section');

/*Adding Nav Items Dynamicly using Javascript Code*/
let i = 0;
let HeadingIndex = 0;
for (i=0;i<theSections.length;i++)
{
  let TheParent = document.getElementById('Parent');
  let NewList = document.createElement('li');
  let NewHeading  = document.createElement('h1');
  TheParent.appendChild(NewList);
  NewList.appendChild(NewHeading);
  NewHeading.className = 'UlSection';
  NewHeading.id = HeadingIndex;
  NewHeading.innerHTML = "Section" +(HeadingIndex+1);
  HeadingIndex++;
}

/*Getting Elements that will be used later in the app*/
let UlSections = document.getElementsByClassName('UlSection');
let scrollPosArray = []

/*This function is a simple loop that gets the scrolling position of each section to be used later to auto scroll*/
function getOffset()
{
for (i=0;i<theSections.length;i++)
{
   scrollPosArray[i] = theSections[i].offsetTop;
}
}
/*The Autoscroll function is called when the users open the page*/
getOffset();


/*This Function is responsible for reaching the scroll position by clicking on any element of the unordered list*/
var theparent = document.querySelector("#Parent");
function autoScrollfromNav(Pixels)
{
  theparent.addEventListener('click',function(e)
  {
    if (e.target !== e.currentTarget)
    {
      var ClickedItem = e.target.id;
      window.scrollTo(0,scrollPosArray[ClickedItem]-Pixels);
    }
    e.stopPropagation();
  },false);
}
/*The Autoscroll function is called when the users open the page*/
autoScrollfromNav(100);


  
/*This code is resposible for applying changes or adding an active class to the selected section in the page
it makes the selected section underlined from the button and the section itself is hovered and scaled to 1.1*/
function applyChanges(index)
{
  for(i=0;i<theSections.length;i++)
  {
    theSections[i].className = 'NonActiveClass'
    UlSections[i].style.borderBottom = "none";
  }
    theSections[index].className = 'ActiveClass'
    UlSections[index].style.borderBottom = "solid 3px black";
}

/*Throughout Scrolling in the whole page the changes is applied to the selected section*/
function scrollCollapsed(ScrollPixels)
{
  onscroll = function () {
   for (i=0;i<theSections.length;i++)
   {
    if(this.scrollY>=scrollPosArray[i]-ScrollPixels&&this.scrollY<scrollPosArray[i]+theSections[i].offsetHeight-ScrollPixels)
    {
      applyChanges(i)
    }
   }
  }
}
scrollCollapsed(300);
/*Using the button to scroll again to top of the page*/
let TopBtn = document.getElementById('Top');
TopBtn.addEventListener('click',function()
{
  window.scrollTo(0,0);
})

/*This Code is responible for collapsing sections of the page by using "Show" and "Hide buttons"*/
let TheBtns = document.getElementsByClassName('btn');
let TheParagraphs = document.getElementsByTagName('p');
let Displayed = [];
/*This Code snipped assignes all displayed array to true automaticlly*/
for (i=0;i<theSections.length;i++)
{
  Displayed[i] = true;
}
for (i of TheBtns) {
  (function(i) {
    i.addEventListener('click', function() {
      if (Displayed[i.id]===true)
      {
        TheBtns[i.id].innerHTML = "Show";
        TheParagraphs[i.id].style.display = 'none';
        Displayed[i.id]=false;
      }
      else
      {
        TheBtns[i.id].innerHTML = "Hide";
        TheParagraphs[i.id].style.display = 'grid';
        Displayed[i.id]=true;
      }
      getOffset();
      /*Adding Media Query To Javascript code Beacuse scrolling throuth the collapsing 
      sections will require different pixels in the parrameters of the function*/
      var MediaQuery = window.matchMedia("(max-width:570px)");
      if (MediaQuery.matches){
        scrollCollapsed(360)
      }
      else
      scrollCollapsed(320)
      
      autoScrollfromNav(300);
    });
  })(i);
}



