# Multi section Landing Page (Udacity Project)

This landing page is consisted of multiple sections. The page contains a JavaScript code that allows the user to smoothly moves to the section choosed in the navigation bar menu. Simply, the user clicks on any section in the nav bar and then the js app automatically scrolls to the selected section. Even when the user scrolls himself on any section, an active class is added to the section.

## Installation

open index.html


## Usage
The project can be used to display any content that contains more than section

## Author
Youssef Yosry Mohamed